pi_estimation_result <- pi_estimation(expression_matrix = GTEx_epithelial_genes,
                                      prior = GTEx_prior,
                                      n_iteration = 5)
